<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

Schema::create('salidas', function (Blueprint $table) {
    $table->id();
$table->foreign('producto_id')->on('producto')->onDelete('set null');
    $table->foreign('cliente_id')->constrained('clientes')->onDelete('set null');
    $table->date('fecha');
    $table->integer('cantidad');
    $table->string('factura_venta');
    $table->softDeletes();
    $table->timestamps();
});

