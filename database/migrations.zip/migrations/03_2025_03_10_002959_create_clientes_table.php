<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

Schema::create('clientes', function (Blueprint $table) {
    $table->id();
    $table->string('dni')->unique();
    $table->enum('tipo_Identificacion',['Cedula de ciudadania','NIT','Cedula de Extranjeria','Pasaporte','Documento de identificación del extranjero'])->nullable();
    $table->string('nombre');
    $table->string('correo')->unique();
    $table->string('telefono');
    $table->date('fecha_registro');
    $table->date('fecha_actualizacion')->nullable();
    $table->softDeletes();
    $table->timestamps();
});

