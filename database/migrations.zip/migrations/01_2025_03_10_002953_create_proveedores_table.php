<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up() {
        Schema::create('proveedores', function (Blueprint $table) {
            $table->string('nit',11)->unique();
            $table->string('digito_verificacion',1);
            $table->string('nombre');
            $table->string('correo')->nullable();
            $table->string('telefono')->nullable();
            $table->string('direccion');
            $table->string('ciudad')->nullable();
            $table->softDeletes(); // SoftDeletes
            $table->timestamps();
        });
    }
    
    public function down() {
        Schema::dropIfExists('proveedores');
    }
};
