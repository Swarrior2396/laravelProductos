<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

Schema::create('entradas', function (Blueprint $table) {
    $table->id();
    $table->foreign('proveedor_id')->references('nit')->on('proveedores')->onDelete('set null');
    $table->foreignId('producto_id')->references('id')->on('producto')->onDelete('set null');
    $table->string('factura_compra');
    $table->date('fecha_compra');
    $table->integer('cantidad');
    $table->softDeletes();
    $table->timestamps();
});
